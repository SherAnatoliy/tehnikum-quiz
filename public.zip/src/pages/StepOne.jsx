import React, { useEffect, useState } from "react";
import { AppHeader } from "../components/AppHeader";
import { AppInput} from "../components/AppInput";
import { AppButton } from "../components/AppButton";

import { useNavigate } from "react-router-dom";
import {ProgressBar} from "../components/PorgressBar";
const StepOne = () => {
  const [text, setText]=useState("")
  const [textError,setTextError] = useState(false)
  const russianTextRegex = /^[А-ЯЁа-яё0-9\s]+$/;
  const navigate = useNavigate();
  let [useError, setUserError] = useState(false)
  let [UserAnswer, setUserAnswer] = useState("")
  const handleClick =()=>{
    if(!russianTextRegex.test(text)){
      setTextError(true)
    }else{
      setTextError(false)
      navigate("/step-two")
    } };
    useEffect(()=>{
      if(!UserAnswer){
         setButtonError(true)
      }else{
        setButtonError(false)
      }
    },[UserAnswer])

  return (
    <div className="container">
      <div className="wrapper">
        <div className="single-input-quiz">

            <ProgressBar  currentStep="1"/>
          <div className="question">
            <AppHeader
        />
    
          <AppInput
           hasError={textError}
            inputLable="" 
            inputPlaceholder="Ваш ответ" 
            inputType="text" 
            id="username" 
            errorText="Введите ваш ответ на русском языке  " 
  
            inputValue={text}
            inputChange={setText}
          />
        
            <AppButton
             isDisabled={useError} 
             buttonType="button" 
             buttonText="Далее"
             buttonClick={handleClick} />
      
          </div>
        </div>
      </div>
    </div>
  );
};

export default StepOne;
